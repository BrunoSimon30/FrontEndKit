const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const helper = require('../utils/helpers.js');
const User = require('../models/users.js');
const SimpleSchema = require('simpl-schema')
const helpers = require('../utils/helpers.js');

const register = async (req, res) => {
    try {
        let body = req.body;
        const userSchema = new SimpleSchema({
            fullName: String,
            userName: {
                type: String,
            },
            phoneNumber: {
                type: String,
                custom() {
                    if (this.value.length > 13 || isNaN(this.value * 1)) return SimpleSchema.ErrorTypes.VALUE_NOT_ALLOWED;
                }
            },
            email: {
                type: String,
                custom() {
                    if (!helper.validateEmail(this.value)) return SimpleSchema.ErrorTypes.VALUE_NOT_ALLOWED;
                }
            },
            password: {
                type: String,
                custom() {
                    if (this.value.length < 8) return SimpleSchema.ErrorTypes.VALUE_NOT_ALLOWED;
                }
            }
        }).newContext();

        if (!userSchema.validate(body)) return res.status(400).json({
            status: "error",
            message: "Please fill all the fields to proceed further!",
            trace: userSchema.validationErrors()
        });

        const userExists = await User.findOne({ $or: [{ email: body.email }, { phoneNumber: body.phoneNumber }, { userName: body.userName }] }).lean();
        if (userExists) return res.status(409).json({
            status: "error",
            message: "Username or Email already exists!"
        });

        body.password = await bcrypt.hash(body.password, 10);
        const inserted = await new User(body).save();
        inserted.verificationToken = jwt.sign({ id: inserted._id, username: inserted.username }, process.env.JWT_SECRET);
        inserted.save();
        return res.json({
            status: "success",
            message: "User Added Successfully",
            data: inserted
        });
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            status: "error",
            message: "unexpected error",
            trace: error.message
        });
    }

}

const login = async (req, res) => {
    try {
        const body = req.body;

        const userSchema = new SimpleSchema({
            email: {
                type: String,
                custom() {
                    if (!helper.validateEmail(this.value)) return SimpleSchema.ErrorTypes.VALUE_NOT_ALLOWED;
                }
            },
            password: {
                type: String,
                custom() {
                    if (this.value < 8) return SimpleSchema.ErrorTypes.VALUE_NOT_ALLOWED;
                }
            },
        }).newContext();


        if (!userSchema.validate(body)) return res.status(409).json({
            status: "error",
            message: "Please fill all the fields to proceed further!",
            trace: userSchema.validationErrors()
        });

        const user = await User.findOne({ email: body.email });
        if (!user) return res.status(409).json({
            status: "error",
            message: "No user found against this phone number!"
        });

        const isPassword = await bcrypt.compare(body.password, user.password);
        if (!isPassword) {
            return res.status(400).json({
                status: "error",
                message: "Incorrect Password.",
                trace: `Password: ${isPassword} is incorrect`
            });
        }
        user.verificationToken = jwt.sign({ id: user._id, phoneNumber: user.phoneNumber }, process.env.JWT_SECRET);
        user.save();    
        return res.json({
            status: "success",
            message: "Login successfully !",
            data: user
        });
    } catch (error) {
        res.json({
            status: "error",
            message: "An unexpected error",
            trace: error.message
        });
    }
}

const updateUser = async (req, res) => {
    try {
        const body = req.body;

        const schema = new SimpleSchema({
            fullName: {
                type: String,
                optional: true
            },
            userName: {
                type: String,
                optional: true,
            },
            password: {
                type: String,
                optional: true
            },
            phoneNumber: {
                type: String,
                optional: true
            },
            about: {
                type: String,
                optional: true
            }
        }).newContext();

        if (!schema.validate(body)) return res.status(409).json({
            status: "error",
            message: "Please fill in all the fields to continue.",
            trace: schema.validationErrors()
        });

        if (body.userName === true) {
            const userExists = await User.find({ userName: body.userName }).lean();
            if (userExists) return res.status(401).json({
                status: "error",
                message: "Username already taken",
                error: error.message,
            });
        }

        if (body.password) body.password = await bcrypt.hash(body.password, 10);
        if (isEmpty(body.password)) delete body.password
        delete body.phoneNumber;


        // 
        const updatedUser = await User.findOneAndUpdate({ _id: req.user._id }, { $set: body }, { new: true, projection: { verificationToken: 0, otpcode: 0, password: 0, blocked: 0, wrongPassAttempts: 0, referral: 0 } });



        return res.json({
            status: "success",
            message: "Your account has been updated!",
            data: updatedUser
        })

    } catch (error) {
        return res.status(500).json({
            status: "error",
            message: "An unexpected error ocurred while proceeding your request.",
            data: null,
            trace: error.message
        });
    }
}

const deleteUser = async (req, res) => {
    try {
        const body = req.body
        const schema = new SimpleSchema({
            password: String,
        }).newContext();

        if (!schema.validate(body)) return res.status(409).json({
            status: "error",
            message: "Please fill all the fields to proceed further!",
            trace: schema.validationErrors()
        });

        const user = await User.findById(req.user._id).lean();
        const checkPassword = await bcrypt.compare(body.password, user.password);
        if (!checkPassword) return res.status(401).json({
            status: "error",
            message: "Invalid password! please try again"
        });

        const deletedUser = await User.findOneAndDelete({ _id: req.user._id });
        if (!deletedUser) {
            res.status(401).json({
                status: "error",
                message: "Please! Insert your _id"
            });
        }
        else {
            res.json({
                status: "success",
                message: "Account is deleted Successfully",
                data: deletedUser
            });
        }

    }
    catch (error) {
        return res.json({
            status: "error",
            message: "something went wrong",
            data: error.message
        })
    }
}

const forgetPassword = async (req, res) => {

    try {
        const body = req.body;

        const userSchema = new SimpleSchema({
            phoneNumber: String
        }).newContext();

        if (!userSchema.validate(body)) return res.status(200).json({
            status: "error",
            message: "Please fill in all the fields precisely to proceed.",
            trace: userSchema.validationErrors()
        });
        const user = await User.findOne({ phoneNumber: body.phoneNumber }).lean();
        if (!user) {
            return res.status(404).json({
                status: "error",
                message: `Not account found on ${body.phoneNumber}`
            });
        };

        const randomCode = Math.floor(100000 + Math.random() * 900000);
        await helper.sendphonecode(randomCode, user.phoneNumber);
        await User.updateOne({ phoneNumber: body.phoneNumber }, { $set: { otpCode: randomCode } });
        return res.json({
            status: "success",
            message: "OTP code send to your number!",
        });

    } catch (error) {
        return res.status(200).json({
            status: "error",
            message: "An unexpected error ocurred while proceeding your requSest.",
            trace: error.message
        });
    }
}

const verifyOtp = async (req, res) => {
    try {
        const body = req.body;

        const schema = new SimpleSchema({
            otpCode: Number,
            phoneNumber: String
        }).newContext();

        let user = await User.findOne({ phoneNumber: body.phoneNumber }).lean();
        if (!user) return res.status(404).json({
            status: "error",
            message: `Not account found on this ${body.phoneNumber}`
        });

        if (user.otpCode != body.otpCode) return res.status(409).json({
            status: "error",
            message: "Invalid OTP Code! Please try again"
        });

        await User.updateOne({ _id: req.user._id }, { $set: { optcode: null } });

        return res.json({
            status: "success",
            message: "Your OTP has been verified!",
        });
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            status: "error",
            message: "An unexpected error ocurred while proceeding your request.",
            trace: error.message
        });
    }
}

const changePassword = async (req, res) => {
    try {
        let body = req.body;

        const userSchema = new SimpleSchema({
            password: String,
            phoneNumber: String,
            otpCode: Number
        }).newContext();
        if (body.password.length < 7) {
            return res.status(409).json({
                status: "error",
                message: "Please fill all the fields to proceed further!",
                trace: userSchema.validationErrors()
            });
        }
        if (!userSchema.validate(body)) return res.status(409).json({
            status: "error",
            message: "Please fill all the fields to proceed further!",
            trace: userSchema.validationErrors()
        });

        const user = await User.findOne({ phoneNumber: body.phoneNumber }).lean();
        if (!user) return res.status(404).json({
            status: "error",
            message: "Couldn't find any account associated with this phone Number."
        });

        if (user.otpCode != body.otpCode) return res.status(401).json({
            status: "error",
            message: "Invalid OTP Code! Please check your phone number or hit resend!"
        });

        if (body.password !== undefined) body.password = await bcrypt.hash(body.password, 10);

        const changePassword = await User.findOneAndUpdate({ phoneNumber: body.phoneNumber }, { $set: { password: body.password, otpCode: null } }, { new: true, projection: { verificationToken: 0, otpcode: 0, password: 0 } });
        return res.json({
            status: "success",
            message: "Your account has been updated!",
            data: changePassword
        });

    } catch (error) {
        res.json({
            status: "error",
            message: "An unexpected error",
            trace: error.message
        })
    }
}

const profilePicture = async (req, res) => {
    try {
        let profilePicture = req.files?.profilePicture;

        if (!profilePicture) return res.status(400).json({
            status: "error",
            message: "please add profile picture to continue.",
            data: null,
        });

        let filename = `public/profiles/${Date.now()}-${profilePicture.name.replace(/ /g, '-').toLowerCase()}`
        await profilePicture.mv(filename)

        profilePicture = filename.replace("public", "");
        const userUpated = await User.findOneAndUpdate({ _id: req.user._id }, { $set: { profile_picture: profilePicture } }, { new: true });
        return res.json({
            status: "success",
            message: "your profile has been updated",
            data: userUpated.profile_picture
        });
    } catch (error) {
        return res.status(500).json({
            status: "error",
            message: "An unexpected error ocurred while proceeding your request.",
            data: null,
            trace: error.message
        });
    }
}

const UserList = async (req, res) => {
    try {
        let query = req.query.search
        const body = req.body
        let UserList = "";


        if (query) {
            UserList = await User.find({ fullName: { $regex: query, $options: "i" } }, { verificationToken: 0, otpCode: 0, password: 0, blocked: 0, wrongPassAttempts: 0, referral: 0 }).lean();

        }
        else {
            UserList = await User.find({}, { verificationToken: 0, otpCode: 0, password: 0, blocked: 0, wrongPassAttempts: 0, referral: 0 }).lean();

        }
        const UserListPaginated = helper.pagination(UserList, req.query.page, req.query.limit);

        return res.json({
            status: "success",
            message: "Your user is here!",
            data: UserListPaginated
        })

    } catch (error) {
        return res.status(500).json({
            status: "error",
            message: "An unexpected error",
            trace: error.message
        })
    }
}

const getUser = async (req, res) => {
    try {
        const user = await User.findById(req.params.id, { verificationToken: 0, otpCode: 0, password: 0 }).lean();
        return res.json({
            status: "Success",
            message: `These all account exists on ${user.email}`,
            data: user
        })
    } catch (error) {
        return res.status(500).json({
            status: "error",
            message: "An unexpected error",
            trace: error.message
        })
    }
}

const deleteProfilePicture = async (req, res) => {
    try {
        let profilePicture = req.files?.profilePicture;

        if (!profilePicture) return res.status(400).json({
            status: "error",
            message: "You've not add a profile picture",
            data: null,
        });
        const userUpated = await User.findOneAndDelete(req.user._id, { profile_picture: profilePicture });
        return res.json({
            status: "success",
            message: "your profile has been Deleted",
        });

    } catch (error) {
        return res.status(500).json({
            status: "error",
            message: "An unexpected error ocurred while proceeding your request.",
            data: null,
            trace: error.message
        });
    }
}

const usersController = {
    register,
    UserList,
    getUser,
    updateUser,
    deleteUser,
    login,
    forgetPassword,
    changePassword,
    verifyOtp,
    profilePicture,
    deleteProfilePicture
};

module.exports = usersController;

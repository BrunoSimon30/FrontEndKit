const express = require("express");
const dotenv = require('dotenv');

const usersRoutes = require("./routes/users.js");
const mongoose = require("mongoose");
const cors = require('cors');
dotenv.config();

var PORT = process.env.PORT,
    DB_URL = process.env.DB_URL
mongoose.connect(DB_URL, (err, db) => {
    if (err) console.error(err);
    // let dbo = db.client.db('tempmail');
    // MongoUtil.getInstance(dbo);
    console.log('Database Connected!');
});

const app = express();
app.use(express.json());
app.use(cors())

app.use("/api/user", usersRoutes);

app.get("/", (req, res) => res.send("Welcome to the Users API!"));
app.all("*", (req, res) => res.status(404).send("You've tried reaching a route that doesn't exist."));

const expressServer = app.listen(PORT, () => {
    console.log(`Server is now up and running on:`);
    console.log(`http://localhost:${PORT}`);
});

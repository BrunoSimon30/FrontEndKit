const helper = require('../utils/helpers.js');
const express = require('express');
const userController = require('../controllers/users.js');

const router = express.Router();

router.post('/', userController.register);
router.post('/login', userController.login);

module.exports = router;
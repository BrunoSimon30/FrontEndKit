const mongoose = require('mongoose');

const usersSchema = new mongoose.Schema({
    fullName: {
        type: String
    },
    userName: {
        type: String
    },
    phoneNumber: {
        type: String
    },
    email: {
        type: String
    },
    password: {
        type: String
    },

});

module.exports = mongoose.model('users', usersSchema);